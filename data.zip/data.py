import os
import json
import pandas as pd
import dask.dataframe as dd
from glob import glob
from abc import ABC, abstractmethod
from memory_profiler import profile
from multiprocessing import Pool

class BaseReader(ABC):
    """数据读取器抽象基类，支持扩展新格式"""
    def __init__(self, path, chunk_size=10000):
        self.path = path
        self.chunk_size = chunk_size
    
    @abstractmethod
    def read_stream(self):
        """返回数据流生成器"""
        pass

class JSONLReader(BaseReader):
    """JSON Lines格式读取器（百万级数据优化）"""
    def read_stream(self):
        with open(self.path, 'r', encoding='utf-8') as f:
            buffer = []
            for i, line in enumerate(f):
                try:
                    buffer.append(json.loads(line))
                    # 达到分块大小时批量返回
                    if len(buffer) >= self.chunk_size:
                        yield buffer
                        buffer = []
                except json.JSONDecodeError as e:
                    print(f"JSON解析错误行 {i}: {str(e)}")
            if buffer:  # 返回剩余数据
                yield buffer

class CSVReader(BaseReader):
    """CSV读取器（支持内存映射和类型推断）"""
    def read_stream(self):
        for chunk in pd.read_csv(
            self.path, 
            chunksize=self.chunk_size,
            low_memory=False,
            memory_map=True,  # 内存映射减少复制[8](@ref)
            dtype_backend='pyarrow'  # 使用pyarrow类型减少内存[1](@ref)
        ):
            yield chunk.to_dict('records')

class ParquetReader(BaseReader):
    """Parquet格式读取器（列式存储优化）"""
    def read_stream(self):
        ddf = dd.read_parquet(
            self.path,
            engine='pyarrow',
            chunksize=self.chunk_size
        )
        for partition in ddf.partitions:
            yield partition.compute().to_dict('records')

class UnifiedDataReader:
    """统一数据读取入口（支持目录和多格式）"""
    def __init__(self, input_path, chunk_size=10000):
        self.input_path = input_path
        self.chunk_size = chunk_size
        self.reader_map = {
            '.jsonl': JSONLReader,
            '.csv': CSVReader,
            '.parquet': ParquetReader
        }
    
    @profile  # 内存使用监控[7](@ref)
    def read_data(self):
        """自动检测路径类型（文件/目录）并返回统一数据流"""
        if os.path.isdir(self.input_path):
            for file_path in self._discover_files():
                yield from self._read_single_file(file_path)
        else:
            yield from self._read_single_file(self.input_path)
    
    def _discover_files(self):
        """发现目录下所有支持格式的文件"""
        for ext in self.reader_map.keys():
            for file_path in glob(os.path.join(self.input_path, f'*{ext}')):
                yield file_path
    
    def _read_single_file(self, file_path):
        """根据扩展名选择读取器"""
        _, ext = os.path.splitext(file_path)
        if ext not in self.reader_map:
            raise ValueError(f"不支持的格式: {ext} (支持: {list(self.reader_map.keys())})")
        
        reader = self.reader_map[ext](file_path, self.chunk_size)
        return reader.read_stream()

# 使用示例 =============================================
if __name__ == "__main__":
    # 1. 处理单文件
    reader = UnifiedDataReader("data/big_data.jsonl")
    for i, chunk in enumerate(reader.read_data()):
        print(f"处理分块 {i}: {len(chunk)}条记录")
        # 在此处添加数据处理逻辑（如发送到模型API）
        # 注意：处理完立即释放chunk引用（避免内存累积）
        del chunk
    
    # 2. 处理整个目录
    dir_reader = UnifiedDataReader("data/raw_files/")
    with Pool(processes=4) as pool:  # 并行处理加速[1](@ref)
        results = pool.imap_unordered(process_chunk, dir_reader.read_data())
        for res in results:
            save_to_database(res)  # 示例存储函数

def process_chunk(chunk):
    """示例处理函数（替换为实际业务逻辑）"""
    # 此处可添加: 数据清洗、特征提取等
    return chunk







# others