import re
import random
import hashlib
import jinja2
from typing import Dict, List, Optional

class KnowledgeExtractor:
    """从文本中提取结构化知识点的核心引擎"""
    def __init__(self, min_entities=3):
        self.min_entities = min_entities  # 最小知识点数量阈值
        self.entity_types = ["概念", "事件", "人物", "地点", "属性", "关系"]
    
    def extract(self, text: str) -> List[Dict]:
        """
        从文本提取知识点三元组（伪代码，实际需集成NLP模型）
        真实场景应集成SPACY/LLM实体识别[3](@ref)
        """
        # 示例伪逻辑 - 实际需替换为NER模型
        entities = []
        if len(text) > 100:  # 长文本处理
            # 1. 关键实体识别（模拟）
            candidate_entities = list(set(re.findall(r'\b[A-Z][a-z]+\b|\b\d{4}\b|\b[\w-]{5,}\b', text)))
            
            # 2. 关系提取（模拟）
            entities = []
            for i, ent in enumerate(candidate_entities[:10]):  # 限制数量
                entities.append({
                    "id": f"entity_{hashlib.md5(ent.encode()).hexdigest()[:8]}",
                    "name": ent,
                    "type": random.choice(self.entity_types),
                    "description": f"关于{ent}的详细说明",
                    "context": text[max(0, text.find(ent)-50):text.find(ent)+50]
                })
        
        # 3. 核心知识点筛选[5](@ref)
        if len(entities) < self.min_entities:
            entities.append({
                "id": "fallback_entity",
                "name": "核心主题",
                "type": "概念",
                "description": text[:100] + "..." if len(text) > 100 else text,
                "context": text
            })
        
        return entities

class PromptTemplateManager:
    """多任务提示词模板管理系统（支持动态注册）[1](@ref)"""
    def __init__(self):
        self.templates = {
            # 内置任务模板（符合CREATE框架[5](@ref)）
            "qa": """
            [角色] 你是一位{{ domain }}领域的专家
            [任务] 基于以下知识生成问答对：
            {% for entity in knowledge %}
            - {{ entity.name }}: {{ entity.description }}
            {% endfor %}
            [要求]
            1. 生成{{ n_questions }}个问题，覆盖核心知识点
            2. 包含选择题和开放性问题
            3. 输出格式: {"questions": [{"type":"单选/开放", "question":"...", "answer":"..."}]}
            """,
            
            "summarization": """
            [角色] 文本摘要专家
            [任务] 请用{{ max_length }}字概括以下内容：
            {{ knowledge[0].context }}
            [要求]
            1. 保留关键实体：{{ entity_names }}
            2. 包含因果关系
            """
        }
        self.env = jinja2.Environment(loader=jinja2.DictLoader(self.templates))
    
    def register_template(self, task_type: str, template: str):
        """注册新任务模板[1,7](@ref)"""
        if task_type in self.templates:
            raise KeyError(f"任务类型 {task_type} 已存在")
        self.templates[task_type] = template
        self.env.loader = jinja2.DictLoader(self.templates)
    
    def get_template(self, task_type: str) -> jinja2.Template:
        """获取Jinja2模板对象"""
        if task_type not in self.templates:
            raise ValueError(f"未知任务类型: {task_type}. 可用类型: {list(self.templates.keys())}")
        return self.env.get_template(task_type)
    
    def render(self, task_type: str, **kwargs) -> str:
        """动态生成提示词[4](@ref)"""
        template = self.get_template(task_type)
        return template.render(**kwargs)
    
    def list_templates(self) -> List[str]:
        """获取所有注册模板的MD5摘要（用于版本追踪）[1](@ref)"""
        return {k: hashlib.md5(v.encode()).hexdigest() for k, v in self.templates.items()}

class TaskFactory:
    """任务实例生成器（支持8种任务类型）"""
    TASK_TYPES = ["qa", "summarization", "cloze", "entity_extraction", 
                 "relation_graph", "timeline", "checklist", "comparison"]
    
    @staticmethod
    def create_task(knowledge: Dict, task_type: str, **params) -> Dict:
        """
        创建任务实例[5](@ref)
        :param knowledge: 知识点字典
        :param task_type: 任务类型标识符
        :param params: 任务特定参数
        :return: 任务字典
        """
        task_map = {
            "qa": lambda: TaskFactory._create_qa(knowledge, **params),
            "summarization": lambda: TaskFactory._create_summary(knowledge, **params),
            "cloze": lambda: TaskFactory._create_cloze(knowledge, **params),
            "entity_extraction": lambda: TaskFactory._create_entity_task(knowledge)
        }
        
        if task_type not in task_map:
            raise ValueError(f"不支持的任务类型: {task_type}")
        
        return {
            "task_id": f"{task_type}_{hashlib.md5(str(knowledge).encode()).hexdigest()[:6]}",
            "task_type": task_type,
            "created_at": datetime.utcnow().isoformat(),
            "content": task_map[task_type]()
        }
    
    @staticmethod
    def _create_qa(knowledge: Dict, n_questions=3) -> List:
        """生成问答任务（含选择题和开放题）[6](@ref)"""
        # 实际实现应调用LLM生成，此处为示例逻辑
        return [{
            "type": random.choice(["单选", "开放"]),
            "question": f"关于{knowledge['name']}的描述正确的是？",
            "options": ["选项A", "选项B", "选项C"] if random.random() > 0.5 else None,
            "answer": "正确答案"
        } for _ in range(n_questions)]
    
    @staticmethod
    def _create_cloze(knowledge: Dict) -> Dict:
        """生成完形填空任务（使用思维链技术[5](@ref)）"""
        # 示例：在描述中挖空关键实体
        desc = knowledge["description"]
        entities = re.findall(r'\b[A-Z][a-z]+\b', desc) or [knowledge["name"]]
        target = random.choice(entities)
        
        return {
            "text": desc.replace(target, "_____"),
            "missing": target,
            "hint": knowledge["context"][:50] + "..."
        }

class InstructionGenerator:
    """指令微调数据生成引擎（集成质量验证）"""
    def __init__(self, template_manager: PromptTemplateManager):
        self.template_manager = template_manager
        self.validator = QualityValidator()
    
    def generate(self, text: str, task_type: str, **params) -> Dict:
        """
        生成单条指令数据[4](@ref)
        1. 提取知识点
        2. 选择模板
        3. 创建任务
        4. 质量验证
        """
        # 1. 知识提取
        knowledge = KnowledgeExtractor().extract(text)
        
        # 2. 动态生成提示词
        prompt = self.template_manager.render(
            task_type,
            knowledge=knowledge,
            domain="科技",
            n_questions=params.get("n_questions", 3),
            max_length=params.get("max_length", 100)
        )
        
        # 3. 创建任务实例
        task = TaskFactory.create_task(knowledge[0], task_type, **params)
        
        # 4. 质量验证
        if not self.validator.validate(task):
            task["quality_flag"] = "low_confidence"
        
        return {
            "instruction": prompt,
            "input": text[:500],  # 截断长文本
            "output": task,
            "metadata": {
                "knowledge_ids": [k["id"] for k in knowledge],
                "template_version": self.template_manager.list_templates()[task_type]
            }
        }
    
    def batch_generate(self, texts: List[str], task_type: str, **params) -> List[Dict]:
        """批量生成指令数据（自动跳过低质量数据）"""
        results = []
        for text in texts:
            try:
                result = self.generate(text, task_type, **params)
                if result["output"].get("quality_flag") != "low_confidence":
                    results.append(result)
            except Exception as e:
                logging.error(f"生成失败: {str(e)}")
        return results

class QualityValidator:
    """任务质量验证器（实现6项验证规则）[4](@ref)"""
    def validate(self, task_data: Dict) -> bool:
        """执行质量检查链"""
        checks = [
            self._check_entity_coverage(task_data),
            self._check_answer_consistency(task_data),
            self._check_context_relevance(task_data),
            self._check_diversity(task_data),
            self._check_ambiguity(task_data),
            self._check_completeness(task_data)
        ]
        return all(checks)
    
    def _check_entity_coverage(self, task: Dict) -> bool:
        """验证关键实体覆盖率[7](@ref)"""
        # 实现实体覆盖检测逻辑
        return len(task.get("entities", [])) >= 3
    
    def _check_answer_consistency(self, task: Dict) -> bool:
        """验证答案一致性（避免矛盾）[4](@ref)"""
        # 实现一致性检查逻辑
        return True

# 使用示例 =======================================================================
if __name__ == "__main__":
    # 初始化组件
    template_mgr = PromptTemplateManager()
    
    # 注册新任务模板（填空任务）[1](@ref)
    cloze_template = """
    [角色] 教育内容设计师
    [任务] 创建完形填空练习
    [知识] 
    {% for entity in knowledge -%}
    - {{ entity.name }}: {{ entity.description }}
    {% endfor %}
    [要求]
    1. 在描述文本中挖空关键术语
    2. 提供术语提示
    3. 输出格式: {"text": "_____文本", "missing": "术语", "hint": "提示"}
    """
    template_mgr.register_template("cloze", cloze_template)
    
    # 生成指令数据
    generator = InstructionGenerator(template_mgr)
    sample_text = "机器学习是人工智能的一个分支，主要研究计算机如何模拟人类的学习行为。1959年，亚瑟·塞缪尔开发了第一个学习程序。"
    
    # 生成问答任务数据
    qa_data = generator.generate(sample_text, "qa", n_questions=2)
    print(json.dumps(qa_data, indent=2, ensure_ascii=False))
    
    # 生成填空任务数据
    cloze_data = generator.generate(sample_text, "cloze")
    print(json.dumps(cloze_data, indent=2, ensure_ascii=False))