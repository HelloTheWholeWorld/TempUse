import json
import os
from typing import Dict, List, Union, Iterator, Optional
import pandas as pd
from tqdm import tqdm

class LLaMADataConverter:
    """LLaMA Factory数据转换模块（支持百万级数据处理）"""
    
    FORMAT_MAPPING = {
        "alpaca": {
            "instruction": "instruction",
            "input": "input",
            "output": "output",
            "system": "system",
            "history": "history"
        },
        "sharegpt": {
            "conversations": "conversations",
            "system": "system_prompt"
        },
        "pretrain": {
            "text": "text"
        },
        "dpo": {
            "prompt": "instruction",
            "chosen": "chosen",
            "rejected": "rejected"
        }
    }
    
    def __init__(self, output_dir: str = "llama_factory_data"):
        """
        初始化转换器
        :param output_dir: 输出目录路径
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def convert_to_alpaca(
        self,
        data: Union[List[Dict], Iterator[Dict]],
        task_type: str = "sft",
        system_prompt: Optional[str] = None,
        chunk_size: int = 10000
    ) -> str:
        """
        转换为Alpaca格式（指令微调）
        :param data: 输入数据（字典列表或生成器）
        :param task_type: 任务类型(sft/pretrain/dpo)
        :param system_prompt: 系统提示词
        :param chunk_size: 分块大小（防止内存溢出）
        :return: 输出文件路径
        """
        output_file = os.path.join(self.output_dir, f"alpaca_{task_type}.json")
        total_count = 0
        
        with open(output_file, 'w', encoding='utf-8') as f:
            # 处理数据分块
            for chunk in self._chunk_generator(data, chunk_size):
                converted_chunk = []
                
                for item in tqdm(chunk, desc=f"转换Alpaca格式({task_type})"):
                    converted = {
                        "instruction": item.get("instruction", ""),
                        "input": item.get("input", ""),
                        "output": item.get("output", "")
                    }
                    
                    # 添加系统提示词
                    if system_prompt:
                        converted["system"] = system_prompt
                    
                    # 添加历史对话（多轮对话）
                    if "history" in item:
                        converted["history"] = [
                            [hist["instruction"], hist["output"]]
                            for hist in item["history"]
                        ]
                    
                    converted_chunk.append(converted)
                    total_count += 1
                
                # 写入文件（增量写入）
                if converted_chunk:
                    json_str = json.dumps(converted_chunk, ensure_ascii=False)
                    f.write(json_str[1:-1] + ",")  # 去除外层[]并添加逗号
        
        print(f"✅ 成功转换 {total_count} 条数据到 Alpaca 格式")
        return output_file
    
    def convert_to_sharegpt(
        self,
        data: Union[List[Dict], Iterator[Dict]],
        task_type: str = "sft",
        system_prompt: Optional[str] = None,
        chunk_size: int = 10000
    ) -> str:
        """
        转换为ShareGPT格式（多轮对话）
        :param data: 输入数据（字典列表或生成器）
        :param task_type: 任务类型
        :param system_prompt: 系统提示词
        :param chunk_size: 分块大小
        :return: 输出文件路径
        """
        output_file = os.path.join(self.output_dir, f"sharegpt_{task_type}.json")
        total_count = 0
        
        with open(output_file, 'w', encoding='utf-8') as f:
            # 处理数据分块
            for chunk in self._chunk_generator(data, chunk_size):
                converted_chunk = []
                
                for item in tqdm(chunk, desc=f"转换ShareGPT格式({task_type})"):
                    converted = {"conversations": []}
                    
                    # 添加系统提示
                    if system_prompt:
                        converted["system"] = system_prompt
                    
                    # 转换对话历史
                    for turn in item["conversations"]:
                        role = "human" if turn["role"] in ["user", "human"] else "assistant"
                        converted["conversations"].append({
                            "from": role,
                            "value": turn["content"]
                        })
                    
                    # 多模态支持（图像/音频）
                    if "image" in item:
                        converted["images"] = [item["image"]]
                    elif "audio" in item:
                        converted["audios"] = [item["audio"]]
                    
                    converted_chunk.append(converted)
                    total_count += 1
                
                # 写入文件
                if converted_chunk:
                    json_str = json.dumps(converted_chunk, ensure_ascii=False)
                    f.write(json_str[1:-1] + ",")
        
        print(f"✅ 成功转换 {total_count} 条数据到 ShareGPT 格式")
        return output_file
    
    def generate_dataset_config(
        self,
        data_files: List[str],
        dataset_name: str,
        task_type: str = "sft",
        format_type: str = "alpaca"
    ) -> Dict:
        """
        生成LLaMA Factory数据集配置文件
        :param data_files: 数据文件路径列表
        :param dataset_name: 数据集名称
        :param task_type: 任务类型(sft/pretrain/dpo)
        :param format_type: 格式类型(alpaca/sharegpt)
        :return: 配置文件字典
        """
        config = {
            dataset_name: {
                "file_name": data_files[0].split('/')[-1],
                "formatting": format_type,
                "columns": {}
            }
        }
        
        # 添加格式特定字段映射
        if format_type in self.FORMAT_MAPPING:
            config[dataset_name]["columns"] = self.FORMAT_MAPPING[format_type].copy()
        
        # 特殊任务配置
        if task_type == "dpo":
            config[dataset_name]["ranking"] = True
        
        # 多文件支持
        if len(data_files) > 1:
            config[dataset_name]["file_name"] = [f.split('/')[-1] for f in data_files]
        
        # 保存配置文件
        config_path = os.path.join(self.output_dir, "dataset_info.json")
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        print(f"✅ 数据集配置文件已生成: {config_path}")
        return config
    
    def _chunk_generator(
        self, 
        data: Union[List[Dict], Iterator[Dict]], 
        chunk_size: int
    ) -> Iterator[List[Dict]]:
        """大数据分块生成器（避免内存溢出）"""
        if isinstance(data, list):
            for i in range(0, len(data), chunk_size):
                yield data[i:i + chunk_size]
        else:  # 处理生成器
            chunk = []
            for item in data:
                chunk.append(item)
                if len(chunk) >= chunk_size:
                    yield chunk
                    chunk = []
            if chunk:
                yield chunk
    
    def convert_csv_to_alpaca(
        self,
        csv_path: str,
        column_mapping: Dict[str, str],
        output_name: str = "alpaca_sft"
    ) -> str:
        """
        从CSV文件直接转换到Alpaca格式
        :param csv_path: CSV文件路径
        :param column_mapping: 列名映射（{'原始列名': '目标字段'}）
        :param output_name: 输出文件名
        :return: 输出文件路径
        """
        output_file = os.path.join(self.output_dir, f"{output_name}.json")
        
        # 使用Pandas分块读取大CSV
        chunks = pd.read_csv(csv_path, chunksize=10000)
        total_rows = 0
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for chunk_df in tqdm(chunks, desc="处理CSV分块"):
                # 转换为字典列表
                data = chunk_df.rename(columns=column_mapping).to_dict('records')
                
                # 转换并写入
                converted = self.convert_to_alpaca(data, write_file=False)
                json_str = json.dumps(converted, ensure_ascii=False)
                f.write(json_str[1:-1] + ",")
                
                total_rows += len(data)
        
        print(f"✅ 成功转换CSV文件: {total_rows}行 -> {output_file}")
        return output_file

# 使用示例 =======================================================================

if __name__ == "__main__":
    # 1. 初始化转换器
    converter = LLaMADataConverter(output_dir="llama_data")
    
    # 2. 示例数据（实际应用中可替换为百万级数据源）
    sample_data = [
        {
            "instruction": "将以下句子翻译成英文",
            "input": "今天天气很好",
            "output": "The weather is nice today"
        },
        {
            "instruction": "计算数学表达式",
            "input": "3 + 5 * 2",
            "output": "13"
        },
        {
            "instruction": "多轮对话示例",
            "history": [
                {"instruction": "你是谁？", "output": "我是AI助手"},
                {"instruction": "你能做什么？", "output": "我能回答问题"}
            ],
            "input": "今天的日期是多少？",
            "output": f"今天是2025-06-15"
        }
    ]
    
    # 3. 转换为Alpaca格式
    alpaca_file = converter.convert_to_alpaca(
        sample_data,
        system_prompt="你是一个有帮助的AI助手",
        task_type="sft"
    )
    
    # 4. 生成数据集配置文件
    config = converter.generate_dataset_config(
        data_files=[alpaca_file],
        dataset_name="my_custom_dataset",
        task_type="sft",
        format_type="alpaca"
    )
    
    # 5. CSV转换示例（适用于大规模数据）
    # converter.convert_csv_to_alpaca(
    #     csv_path="big_data.csv",
    #     column_mapping={
    #         "question": "instruction",
    #         "context": "input",
    #         "answer": "output"
    #     }
    # )