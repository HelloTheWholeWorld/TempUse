from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import logging
import asyncio
import time

# ===================== 精简模块实现 =====================
class UnifiedDataReader:
    """精简数据读取器（模拟实现）"""
    def __init__(self, source, chunk_size=5000):  # 减小分块大小便于测试
        self.source = source
        self.chunk_size = chunk_size
        self.logger = logging.getLogger("data_reader")
    
    def read_data(self):
        """流式数据读取（模拟百万级数据处理）"""
        self.logger.info(f"📥 开始读取数据源: {self.source}")
        for i in range(0, 100, self.chunk_size):
            chunk = [f"数据样本_{i+j}" for j in range(self.chunk_size)]
            self.logger.info(f"读取分块 #{i//self.chunk_size+1} ({len(chunk)}条记录)")
            yield chunk
            time.sleep(0.1)  # 模拟IO延迟

class InstructionGenerator:
    """提示词生成引擎"""
    def __init__(self):
        self.templates = {
            ("finance", "qa"): "金融领域QA: 请分析文本并生成问题：{text}",
            ("tech", "summary"): "技术领域摘要: 请总结核心内容：{text}"
        }
    
    def generate(self, text, task_type="qa", domain="general"):
        """动态生成领域提示词"""
        template = self.templates.get(
            (domain, task_type), 
            f"通用任务: 请处理文本：{{text}}"
        )
        return template.format(text=text[:200])  # 截断长文本

class ModelAPIClient:
    """模型调用客户端（精简异步实现）"""
    async def process_batch(self, prompts, max_concurrent=10):
        """异步批量处理（保留核心并发控制）"""
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def process_one(prompt):
            async with semaphore:
                # 模拟API调用延迟 (0.1-0.5秒)
                await asyncio.sleep(0.1 + random.random() * 0.4)
                return f"模型响应: {prompt[:50]}..."
        
        return await asyncio.gather(*[process_one(p) for p in prompts])

class LLaMADataConverter:
    """LLaMA格式转换器"""
    def __init__(self, output_path):
        self.output_path = output_path
        self.logger = logging.getLogger("data_converter")
    
    def convert_to_alpaca(self, results):
        """转换模型输出为标准格式"""
        formatted = [
            {"instruction": res.split(":")[0], "output": res}
            for res in results
        ]
        self.logger.info(f"🔄 已转换 {len(formatted)} 条数据")
        return formatted

# ===================== 核心工作流函数 =====================
def data_processing_workflow():
    """精简工作流引擎（保留异步批处理）"""
    logger = logging.getLogger("workflow")
    logger.info("🚀 启动数据处理工作流")
    
    # 1. 初始化组件
    reader = UnifiedDataReader("s3://data-bucket/raw")
    prompt_engine = InstructionGenerator()
    model_client = ModelAPIClient()
    converter = LLaMADataConverter("s3://data-bucket/llama_data")
    
    # 2. 分块处理流水线
    for i, chunk in enumerate(reader.read_data()):
        logger.info(f"🔁 处理分块 #{i+1} ({len(chunk)}条记录)")
        
        # 2.1 生成提示词
        prompts = [
            prompt_engine.generate(text, task_type="qa", domain="finance")
            for text in chunk
        ]
        
        # 2.2 异步模型调用
        results = asyncio.run(model_client.process_batch(prompts))
        
        # 2.3 格式转换
        llama_data = converter.convert_to_alpaca(results)
        
        # 2.4 结果记录（精简版）
        if i % 5 == 0:  # 每5个分块记录一次
            logger.info(f"📝 输出样例: {llama_data[0]}")

# ===================== Airflow DAG定义 =====================
with DAG(
    "llm_data_factory", 
    schedule_interval="@daily",
    start_date=datetime(2025, 6, 15),  # 使用当前日期
    default_args={
        "retries": 3,
        "retry_delay": timedelta(minutes=10)
    },
    catchup=False
) as dag:
    
    process_task = PythonOperator(
        task_id="process_data",
        python_callable=data_processing_workflow,
        execution_timeout=timedelta(hours=3)
    )

# ===================== 直接运行支持 =====================
if __name__ == "__main__":
    # 本地运行配置
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S"
    )
    
    # 启动工作流
    data_processing_workflow()