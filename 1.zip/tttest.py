from typing import List, Dict
import re

def parse_generated_content(response: str) -> List[Dict]:
    """解析API生成的简单键值对内容，保留原始格式"""
    results = []
    blocks = re.split(r'---', response.strip())
    current_item = {}
    key = None
    for block in blocks:
        if not block.strip():
            continue
        # print(blocks)
        lines = block.splitlines()
        # print(lines)
        current_item = {}
        parsing_value = False
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # 检测键值对
            if re.match(r'^(qtype|qtypedesc|level|question|answer):', line, re.IGNORECASE):
                parts = line.split(':', 1)
                key = parts[0].strip().lower()
                value = parts[1].strip() if len(parts) > 1 else ""
                
                # 统一键名
                if key in ["qtype"]:
                    key = "question_type"
                elif key in ["qtypedesc"]:
                    key = "description"
                elif key in ["level"]:
                    key = "difficulty_level"
                elif key in ["question"]:
                    key = "question"
                elif key in ["answer"]:
                    key = "answer"
                
                current_item[key] = value
                parsing_value = False
            else:
                # 继续添加多行内容
                if key and key in current_item:
                    # 对于问题和答案，保留原始格式和换行
                    if key in ["question", "answer"]:
                        current_item[key] += "\n" + line
                    else:
                        current_item[key] += " " + line
                elif key:
                    # 处理未定义的新键值
                    current_item[key] = line
                    parsing_value = True
                else:
                    # 如果当前没有键，则默认为答案内容
                    if "answer" not in current_item:
                        current_item["answer"] = ""
                    current_item["answer"] += "\n" + line
                    key = "answer"
        
        # 后处理：确保必要字段存在
        current_item.setdefault("question_type", "unknown")
        current_item.setdefault("difficulty_level", "2")
        current_item.setdefault("description", f"{current_item['question_type']}问题")
        
        # 验证并保存结果
        if all(k in current_item for k in ["question_type", "question", "answer"]):
            results.append({
                "question_type": current_item["question_type"],
                "description": current_item["description"],
                "difficulty_level": current_item["difficulty_level"],
                "question": current_item["question"].strip(),
                "answer": current_item["answer"].strip()
            })
    
    return results

text = """
qtype:rewrite_expand_rewrite  
level:1  
question:第三宇宙速度的定义是什么？  
answer:第三宇宙速度是指航天器从地球出发，能够逃逸太阳系所需的总速度。它包括脱离地球引力所需的速度（约 11.18 km/s）和脱离太阳系所需的速度（约 12.36 km/s），总速度约为 16.67 km/s。  
---  
qtype:calculate_complex_formula_calculate  
level:3  
question:计算脱离太阳系所需的速度。  
answer:脱离太阳系所需的速度 $ V_3' $ 的计算公式为 $ V_3' = \sqrt{\frac{\mu_{\mathrm{s}}}{R_{\mathrm{s}}}} $。已知 $ \mu_{\mathrm{s}} = 1.327 \times 10^{11} $ km³/s²，$ R_{\mathrm{s}} = 1.496 \times 10^4 $ km，则 $ V_3' = 42.12 $ km/s。qtype:explain_purpose  
desc:阐述火箭发动机原理在航天中的作用  
level:1  
question:火箭发动机在航天中的主要作用是什么？  
answer:火箭发动机是航天器进入大气层外并获得第一宇宙速度的关键动力系统。它通过燃烧化学燃料产生高温高压气体，经喷管高速喷出，产生反作用推力，使火箭获得加速度向前飞行。  
---  
qtype:find_key_issues  
desc:找出固体火箭发动机设计的关键问题  
level:2  
question:为什么固体火箭发动机需要控制药剂燃烧速度？  
answer:固体火箭发动机需要控制药剂燃烧速度，是为了避免过大的推力导致发射载荷和控制设备无法承受。通过控制燃烧速度，可以确保火箭在工作过程中保持较稳定的推力，同时延长工作时间，提高效率。  
---  
qtype:summarize_text  
desc:总结液体火箭发动机的组成结构  
level:1  
question:液体火箭发动机主要由哪些部分组成？  
answer:液体火箭发动机主要由发动机本体、涡轮泵、各种阀门、管路和推进剂贮箱等组成。其中发动机本体包括喷注器、燃烧室和拉瓦尔喷管。  
---  
qtype:generate_report  
desc:生成关于液体火箭发动机的工作原理报告  
level:2  
question:请生成一份关于液体火箭发动机工作原理的简要报告  
answer:液体火箭发动机通过将酒精和液氧作为推进剂，在燃烧室内燃烧产生高温高压气体。喷注器将推进剂按一定比例注入燃烧室并雾化，燃烧后的高温气体经拉瓦尔喷管加速喷出，产生反作用推力。涡轮泵负责将推进剂以高于燃烧室压力送入燃烧室，确保燃烧充分。  
---  
qtype:explain_purpose  
desc:解释双组元液体火箭发动机的用途  
level:1  
question:双组元液体火箭发动机的主要用途是什么？  
answer:双组元液体火箭发动机主要用于航天发射任务，其通过使用酒精和液氧作为推进剂，提供高比冲的推力，能够有效提高火箭的效率和性能。  
---  
qtype:find_key_issues  
desc:找出提高火箭效率的关键手段  
level:2  
question:为什么多级火箭能提高火箭效率？  
answer:多级火箭通过在第一级工作完成后抛弃整个级段，从而减少火箭总质量，降低所需的推进剂量，使火箭能够更高效地达到目标轨道，显著提高整体效率。  
---  
qtype:name_proper_noun  
desc:识别液体火箭推进剂的专有名词  
level:1  
question:请指出双组元液体火箭发动机中常用的两种推进剂名称  
answer:双组元液体火箭发动机中常用的两种推进剂是酒精（燃烧剂）和液氧（氧化剂）。  
---  
qtype:summarize_text  
desc:总结液体火箭发动机冷却方式  
level:1  
question:液体火箭发动机如何防止高温损坏？  
answer:为了防止高温损坏，液体火箭发动机采用燃烧剂通过发动机夹层进行冷却的方式。燃烧剂在燃烧室燃烧后产生的高温气体经过冷却后，再喷出，从而保护发动机结构不被损坏。  
---  
qtype:generate_report  
desc:生成关于固体火箭发动机冷却方法的报告  
level:2  
question:请生成一份关于固体火箭发动机冷却方法的报告  
answer:固体火箭发动机通过将药剂制成中间空心的圆柱形，点火后从中心开始燃烧，逐渐向外烧蚀。未燃烧的药剂起到绝热作用，同时控制燃烧速度，防止发动机因高温而损坏。这种设计有助于维持较低的燃气温度和压力，提高发动机的耐久性和安全性。  
---  
qtype:find_key_issues  
desc:找出提高比冲的关键因素  
level:2  
question:哪种推进剂具有最高的比冲？  
answer:液氢和液氧组成的低温推进剂具有最高的比冲，约为480秒，远高于其他类型的推进剂，因此在高性能火箭中被广泛应用。qtype:explain_difference  
desc:解释齐奥尔科夫斯基公式与牛顿第二定律的区别  
level:2  
question:齐奥尔科夫斯基公式和牛顿第二定律在描述火箭运动时有什么不同？  
answer:齐奥尔科夫斯基公式是专门用于描述变质量物体（如火箭）速度变化的公式，考虑了推进剂喷出对质量的影响，而牛顿第二定律适用于质量恒定的物体。齐奥尔科夫斯基公式推导时引入了推进剂喷气速度和质量变化率，因此更适用于火箭这类质量不断减少的系统。  
---  
qtype:describe_benefit  
desc:阐明齐奥尔科夫斯基公式在航天领域的价值  
level:1  
question:齐奥尔科夫斯基公式在航天领域有什么实际应用价值？  
answer:齐奥尔科夫斯基公式为火箭设计提供了理论基础，帮助工程师计算火箭发射时的速度增量，从而确定所需推进剂量和结构设计。它在航天器发射、轨道转移和深空探测中具有关键作用。  
---  
qtype:provide_list  
desc:列举齐奥尔科夫斯基公式中的关键参数  
level:1  
question:齐奥尔科夫斯基公式中包含哪些关键物理量？  
answer:- $ \Delta v $：速度增量，单位为m/s  
- $ w $：喷气速度，单位为m/s  
- $ m_0 $：初始质量，单位为kg  
- $ m_t $：最终质量，单位为kg  
---  
qtype:design_experiment  
desc:设计一个验证齐奥尔科夫斯基公式的简单实验  
level:2  
question:如何设计一个实验来验证齐奥尔科夫斯基公式？  
answer:可以使用一个可调节质量的模型火箭和高速摄像机，记录火箭发射前后的速度变化，并测量喷气速度和质量变化。通过计算速度增量与质量比的关系，验证公式 $ \Delta v = w \ln \frac{m_0}{m_t} $ 的准确性。  
---  
qtype:explain_difference  
desc:解释“质量变化率”与“喷气速度”的区别  
level:2  
question:质量变化率和喷气速度在齐奥尔科夫斯基公式中分别代表什么？  
answer:质量变化率 $ \frac{dm}{dt} $ 表示单位时间内推进剂喷出的质量，单位为kg/s；喷气速度 $ w $ 是推进剂喷出时相对于火箭的速度，单位为m/s。两者共同决定了火箭的速度增量。  
---  
qtype:suggest_title  
desc:为齐奥尔科夫斯基公式撰写一个标题  
level:1  
question:为齐奥尔科夫斯基公式拟一个合适的标题  
answer:“火箭速度增量的决定因素：齐奥尔科夫斯基公式”  
---  
qtype:provide_list  
desc:列举齐奥尔科夫斯基公式的两种常见形式  
level:1  
question:齐奥尔科夫斯基公式有哪两种常见表达形式？  
answer:- $ \Delta v = w \ln \frac{m_0}{m_t} $  
- $ m_0 = m_t e^{\frac{\Delta v}{w}} $  
---  
qtype:explain_difference  
desc:解释“速度增量”与“加速度”的区别  
level:2  
question:速度增量和加速度在火箭运动中有何不同？  
answer:速度增量 $ \Delta v $ 是火箭在一段时间内速度的变化量，单位为m/s；加速度则是速度变化率，单位为m/s²。齐奥尔科夫斯基公式关注的是总速度变化，而非瞬时加速度。  
---  
qtype:design_experiment  
desc:设计一个实验测量喷气速度  
level:2  
question:如何设计一个实验测量火箭喷气速度？  
answer:可以使用高速摄影机拍摄火箭喷气过程，通过分析喷气轨迹和时间间隔计算喷气速度。或者利用压力传感器测量喷气口处的气体压力，结合流体力学公式计算速度。  
---  
qtype:calculate_complex_formula  
desc:根据齐奥尔科夫斯基公式进行计算  
level:3  
question:若推进剂喷气速度为3.0km/s，初始质量为500kg，最终质量为100kg，求速度增量。  
answer:根据公式 $ \Delta v = w \ln \frac{m_0}{m_t} $，代入数据得：  
$$
\Delta v = 3000 \ln \frac{500}{100} = 3000 \times 1.6094 = 4828.2 \, \text{m/s}
$$  
速度增量为4828.2 m/s。
"""
from pprint import pprint
pprint(parse_generated_content(text), indent=2)
