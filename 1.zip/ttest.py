# import requests

# def call_qwen_api(prompt, api_key):
#     url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
#     headers = {
#         "Authorization": f"Bearer {api_key}",
#         "Content-Type": "application/json"
#     }
#     data = {
#             "model": "qwen3-0.6b",
#             "input": {
#                 "messages": [
#                     {"role": "system", "content": ""},
#                     {"role": "user", "content": "你好，测试一下"}
#                 ]
#             },
#             "parameters": {
#                 "result_format": "message",
#                 "temperature": 0.7,
#                 "top_p": 1.0,
#                 "enable_search": False,
#                 "stream": False,
#                 "enable_thinking": False
#             }
#         },
#     response = requests.post(url, headers=headers, json=data)
#     print(response.json())
#     return response.json()["choices"][0]["message"]["content"]
# print(123)
# # 使用示例
# api_key = "sk-426c613869b34e508a78e0153e3198e6"
# response = call_qwen_api("解释量子纠缠现象", api_key)
# print(response)
import requests
import json

def call_qwen_api(prompt, api_key):
    """
    调用通义千问API的优化版本
    参数:
        prompt: 用户输入的提示词
        api_key: 通义千问API密钥
    返回:
        API返回的文本内容或错误信息
    """
    url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-DashScope-Async": "disable"  # 确保同步调用
    }
    
    data = {
        "model": "qwen3-0.6b",  # 使用更稳定的模型版本
        "input": {
            "messages": [
                {"role": "system", "content": "你是一个专业的人工智能助手"},
                {"role": "user", "content": prompt}
            ]
        },
        "parameters": {
            "result_format": "message",
            "temperature": 0.7,
            "top_p": 1.0,
            "enable_search": False,  # 开启联网搜索增强
            "stream": False,
            "enable_thinking": False
        }
    }
    print(data)
    print(headers)
    try:
        response = requests.post(
            url,
            headers=headers,
            data=json.dumps(data),  # 使用data参数确保正确编码
            timeout=30
        )
        response_data = response.json()
        
        # 调试用 - 打印完整响应
        print("API完整响应:", json.dumps(response_data, indent=2, ensure_ascii=False))
        
        if response.status_code != 200:
            error_msg = response_data.get("message", "未知错误")
            raise Exception(f"API错误 [{response.status_code}]: {error_msg}")
            
        if "output" not in response_data:
            raise Exception("API返回结构异常，缺少output字段")
            
        return response_data["output"]["choices"][0]["message"]["content"]
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"网络请求失败: {str(e)}")
    except json.JSONDecodeError:
        raise Exception("API返回非JSON格式响应")
    except KeyError as e:
        raise Exception(f"API返回数据结构异常，缺少关键字段: {str(e)}")

# 测试用例
if __name__ == "__main__":
    # 测试用API密钥（请替换为真实密钥）
    test_api_key = "sk-426c613869b34e508a78e0153e3198e6"
    
    test_prompts = [
        "你好",  # 简单问候测试
        "解释量子纠缠现象",  # 知识问答测试
        "2023年诺贝尔奖得主是谁？"  # 需要联网搜索的问题
    ]
    
    for prompt in test_prompts:
        try:
            print(f"\n=== 测试问题: {prompt} ===")
            result = call_qwen_api(prompt, test_api_key)
            print("API返回结果:", result)
        except Exception as e:
            print(f"调用失败: {str(e)}")


# {'model': 'qwen3-0.6b', 'input': {'messages': [{'role': 'system', 'content': ''}, {'role': 'user', 'content': '解释量子计算的基本原理'}]}, 'parameters': {'result_format': 'message', 'temperature': 0.7, 'top_p': 1.0, 'enable_search': True, 'stream': False, 'enable_thinking': False}}
# {'Content-Type': 'application/json', 'Authorization': 'Bearer sk-426c613869b34e508a78e0153e3198e6'}

# {'model': 'qwen3-0.6b', 'input': {'messages': [{'role': 'system', 'content': ''}, {'role': 'user', 'content': '你好'}]}, 'parameters': {'result_format': 'message', 'temperature': 0.7, 'top_p': 1.0, 'enable_search': False, 'stream': False, 'enable_thinking': False}}
# {'Authorization': 'Bearer sk-426c613869b34e508a78e0153e3198e6', 'Content-Type': 'application/json', 'X-DashScope-Async': 'disable'} 