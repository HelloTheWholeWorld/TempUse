import os
import re
import logging
from typing import Dict, Any, List, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("MarkdownParser")

def is_heading(line: str, heading_levels: List[int]) -> "tuple[bool, int, str]":
    """检查行是否为指定级别的标题，并返回标题级别和内容"""
    match = re.match(r'(#+)\s+(.*)', line)
    if match:
        level = len(match.group(1))
        if level in heading_levels:
            return True, level, match.group(2).strip()
    return False, 0, ""

def read_md_by_heading_depth(file_path: str, heading_levels: List[int]) -> Dict[str, Any]:
    """
    按照指定的标题深度读取 Markdown 文件，并返回结构化数据。
    
    参数:
    file_path: Markdown 文件路径
    heading_levels: 需要读取的标题深度列表，如 [3] 表示只读取三级标题
    
    返回:
    结构化的字典树
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    root = {"title": "root", "heading_level": 0, "content": "", "children": []}
    stack = [root]  # 使用栈来维护当前所在的层级
    current_content = ""  # 当前累积的内容

    for line in lines:
        line = line.rstrip('\r\n')  # 去掉换行符
        is_h, level, title = is_heading(line, heading_levels)

        if is_h:
            # 如果当前有累积的内容，添加到栈顶节点
            if current_content.strip():
                stack[-1]["content"] += current_content + "\n"
                current_content = ""

            # 如果当前标题深度小于等于栈顶的深度，则需要回退栈
            while stack and level <= stack[-1]["heading_level"]:
                stack.pop()

            # 创建新的节点
            new_node = {
                "title": title,
                "heading_level": level,
                "content": "",
                "children": []
            }

            # 将新节点添加到当前栈顶的 children 中
            stack[-1]["children"].append(new_node)

            # 将新节点压入栈
            stack.append(new_node)
        else:
            # 如果不是标题行，累积内容
            current_content += line + "\n"

    # 处理文件末尾可能剩余的内容
    if current_content.strip():
        stack[-1]["content"] += current_content

    return root

def print_structure(node: Dict, level: int = 0) -> None:
    """递归打印树形结构"""
    indent = "  " * level
    print(f"{indent}- {node['title']} (Level: {node['heading_level']})")
    
    if node["content"].strip():
        content_preview = node["content"].replace("\n", " ").strip()[:50] + "..." if len(node["content"]) > 50 else node["content"].strip()
        print(f"{indent}  Content: {content_preview}")
    
    for child in node["children"]:
        print_structure(child, level + 1)

def get_section_content_with_title(node: Dict[str, Any]) -> str:
    """
    获取节点及其子节点的完整内容（包括标题）
    
    返回格式:
    ### 标题文本
    节点内容
    子节点内容...
    """
    # 添加节点自己的标题
    content = f"{'#' * node['heading_level']} {node['title']}\n\n"
    
    # 添加节点内容
    if node.get("content", "").strip():
        content += node["content"] + "\n\n"
    
    # 递归添加子节点内容（包括它们的标题）
    for child in node.get("children", []):
        content += get_section_content_with_title(child) + "\n\n"
    
    return content.strip()

def extract_sections(
    file_path: str, 
    heading_levels: List[int] = [3], 
    chunk_max_length: int = 4000, 
    min_chunk_length: int = 500, 
    debug: bool = False, 
    debug_k: int = 3
) -> List[str]:
    """
    从Markdown文件中提取指定标题层级的内容，并按指定长度分块
    
    参数:
    file_path: Markdown文件路径
    heading_levels: 要提取的标题层级列表，默认为三级标题
    chunk_max_length: 每个chunk的最大字符长度
    min_chunk_length: 最小字符长度，小于此值的chunk会被丢弃
    debug: 调试模式，开启后只返回前debug_k个chunk
    debug_k: 调试模式下返回的chunk数量
    
    返回:
    分块后的文本列表
    """
    # 1. 读取并解析Markdown文件
    structured_data = read_md_by_heading_depth(file_path, heading_levels)
    
    # 2. 收集所有指定层级的节点
    nodes_to_process = []
    queue = [structured_data]
    
    while queue:
        current = queue.pop(0)
        # 只处理指定层级的节点
        if current.get("heading_level", 0) in heading_levels:
            nodes_to_process.append(current)
        
        # 将子节点加入队列（广度优先）
        queue.extend(current.get("children", []))
    
    logger.info(f"找到 {len(nodes_to_process)} 个指定层级标题")
    
    # 3. 处理每个节点并分块
    all_chunks = []
    
    for node in nodes_to_process:
        # 获取该节点及其子节点的完整内容（包括标题）
        full_content = get_section_content_with_title(node)
        
        # 如果没有内容，跳过
        if not full_content.strip():
            continue
        
        # 计算分块数量（考虑标题长度和内容长度）
        content_length = len(full_content)
        chunks = []
        
        # 如果内容小于最大分块长度，整个部分当作一个chunk
        if content_length <= chunk_max_length:
            if content_length >= min_chunk_length:
                chunks.append(full_content)
        else:
            # 内容过长，需要分块
            start_index = 0
            
            while start_index < content_length:
                # 找到最佳分块位置（在段落末尾切分）
                end_index = min(start_index + chunk_max_length, content_length)
                
                # 尝试在段落结束处分块
                if end_index < content_length:
                    # 从当前位置往前查找段落结束位置
                    para_end = full_content.rfind('\n\n', start_index + min_chunk_length, end_index)
                    if para_end != -1:
                        end_index = para_end + 2  # 包含两个换行符
                    else:
                        # 找不到段落结束，尝试在句子结束处分块
                        sentence_end = full_content.rfind('. ', start_index + min_chunk_length, end_index)
                        if sentence_end != -1:
                            end_index = sentence_end + 1  # 包含句点和空格
                        else:
                            # 在换行处分块
                            line_end = full_content.rfind('\n', start_index + min_chunk_length, end_index)
                            if line_end != -1:
                                end_index = line_end + 1  # 包含换行符
                
                chunk = full_content[start_index:end_index].strip()
                
                # 跳过过小的分块
                if len(chunk) >= min_chunk_length:
                    chunks.append(chunk)
                
                start_index = end_index
    
        # 添加该节点产生的所有分块
        all_chunks.extend(chunks)
    
    logger.info(f"生成 {len(all_chunks)} 个分块")
    
    # 4. 调试模式处理
    if debug:
        if debug_k > 0 and all_chunks:
            return all_chunks[:min(debug_k, len(all_chunks))]
        return all_chunks[:1] if not all_chunks else []
    
    return all_chunks

# 使用示例
if __name__ == "__main__":
    # 配置需要读取的标题深度，比如只读取 h3
    heading_levels_to_read = [3]
    md_file_path = "./data/b19159.md"  # 替换为你的Markdown文件路径
    
    # 读取并分块处理Markdown文件
    chunks = extract_sections(
        md_file_path,
        heading_levels=heading_levels_to_read,
        chunk_max_length=4096,  # 4K字符
        min_chunk_length=512,   # 最小500字符
        debug=True,             # 调试模式
        debug_k=3               # 调试模式下只返回3个分块
    )
    
    # 打印结果
    for i, chunk in enumerate(chunks):
        print(f"\n======= Chunk {i+1} =======\n")
        print(chunk[:20])  # 打印每个分块的前1000字符
        print("\n...\n" if len(chunk) > 1000 else "")  # 如果分块过长，显示省略号
        print("=" * 50 + "\n")