import asyncio
import aiohttp
import json
import logging
import os
from datetime import datetime
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type
)
from typing import Dict, Any, List, Optional, Union
from data_reader import extract_sections
import random
from jinja2 import Template

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("ModelAPIEngine")

class ModelAPIClient:
    """统一多模型API客户端，支持云端API和本地Ollama"""
    
    def __init__(
        self,
        model_type: str = "openai",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model_name: str = "gpt-4-turbo",
        max_retries: int = 3,
        timeout: int = 60,
        max_concurrent: int = 10,
        save_results: bool = False,
        output_dir: str = "results",
        **kwargs
    ):
        """
        初始化API客户端
        :param model_type: 模型类型 (openai/deepseek/volcano/ollama/qwen)
        :param api_key: API密钥（云端API需要）
        :param base_url: 自定义基础URL（可选）
        :param model_name: 模型名称
        :param max_retries: 最大重试次数
        :param timeout: 请求超时时间（秒）
        :param max_concurrent: 最大并发请求数
        :param save_results: 是否保存结果文件
        :param output_dir: 结果保存目录
        :param kwargs: 模型特定参数，如temperature, top_p等
        """
        self.model_type = model_type.lower()
        self.api_key = api_key
        self.model_name = model_name
        self.max_retries = max_retries
        self.timeout = timeout
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.model_kwargs = kwargs  # 存储模型特定参数
        self.save_results = save_results
        self.output_dir = output_dir
        
        # 确保输出目录存在
        if save_results:
            os.makedirs(self.output_dir, exist_ok=True)
            logger.info(f"结果将保存到目录: {os.path.abspath(self.output_dir)}")
        
        # 设置API基础URL
        self.base_url = self._resolve_base_url(base_url)
        
        # 设置特定API端点
        self.endpoints = {
            "openai": "/v1/chat/completions",
            "deepseek": "/v1/chat/completions",
            "volcano": "/api/v1/chat",
            "ollama": "/api/generate",
            "qwen": "/api/v1/services/aigc/text-generation/generation"
        }

        # 模型特定参数模板
        self.payload_templates = {
            "openai": {
                "model": model_name,
                "messages": [{"role": "user", "content": ""}],
                "temperature": 0.7,
                "top_p": 1.0,
                "max_tokens": None,
                "stream": False
            },
            "deepseek": {
                "model": model_name,
                "messages": [{"role": "user", "content": ""}],
                "temperature": 0.7,
                "top_p": 1.0,
                "max_tokens": None,
                "stream": False
            },
            "volcano": {
                "model": model_name,
                "messages": [{"role": "user", "content": ""}],
                "temperature": 0.7,
                "top_p": 1.0,
                "max_tokens": None,
                "stream": False
            },
            "qwen": {
                "model": model_name,
                "input": {
                    "messages": [
                        {"role": "system", "content": ""},
                        {"role": "user", "content": ""}
                    ]
                },
                "parameters": {
                    "result_format": "message",
                    "temperature": 0.7,
                    "top_p": 1.0,
                    "enable_search": False,
                    "stream": False,
                    "enable_thinking": False
                }
            },
            "ollama": {
                "model": model_name,
                "prompt": "",
                "stream": False,
                "options": {
                    "temperature": 0.7,
                    "top_p": 1.0,
                    "num_ctx": 2048
                }
            }
        }
        
        logger.info(f"Initialized {model_type.upper()} client for model: {model_name}")

    def _resolve_base_url(self, base_url: Optional[str]) -> str:
        """解析基础URL"""
        if base_url:
            return base_url.rstrip('/')
        
        # 默认URL配置
        defaults = {
            "openai": "https://api.openai.com",
            "deepseek": "https://api.deepseek.com",
            "volcano": "https://open.volcengineapi.com",
            "ollama": "http://localhost:11434",
            "qwen": "https://dashscope.aliyuncs.com"
        }
        return defaults.get(self.model_type, "")
    
    def _build_payload(self, prompt: str) -> Dict[str, Any]:
        """构建模型特定的请求负载"""
        if self.model_type not in self.payload_templates:
            raise ValueError(f"Unsupported model type: {self.model_type}")
        
        payload = self.payload_templates[self.model_type].copy()

        # 更新payload中的模型特定参数
        if self.model_type == "ollama":
            payload["prompt"] = prompt
            # 更新Ollama的options参数
            for key in ["temperature", "top_p", "num_ctx"]:
                if key in self.model_kwargs:
                    payload["options"][key] = self.model_kwargs[key]
        elif self.model_type == "qwen":
            # 更新Qwen的消息内容
            payload["input"]["messages"][1]["content"] = prompt

            payload["parameters"]["stream"] = False  
            
            # 更新参数
            for key in ["temperature", "top_p", "enable_search"]:
                if key in self.model_kwargs:
                    payload["parameters"][key] = self.model_kwargs[key]
                    
            # 特殊参数处理
            if "enable_thinking" in self.model_kwargs:
                payload["parameters"]["enable_thinking"] = self.model_kwargs["enable_thinking"]
        else:
            payload["messages"][0]["content"] = prompt
            # 更新通用参数
            for key in ["temperature", "top_p", "max_tokens", "stream"]:
                if key in self.model_kwargs:
                    payload[key] = self.model_kwargs[key]
        return payload
    
    def _build_headers(self) -> Dict[str, str]:
        """构建请求头，包含认证信息"""
        headers = {"Content-Type": "application/json"}
        
        if self.model_type == "openai" and self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.model_type == "deepseek" and self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.model_type == "volcano" and self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.model_type == "qwen" and self.api_key:
            # 添加官方要求的额外头部
            headers["Authorization"] = f"Bearer {self.api_key}"
            headers["X-DashScope-Async"] = "disable"  # 确保同步调用

        # Ollama不需要认证头
        
        return headers
    
    def _extract_response(self, response_data: Dict) -> str:
        """从不同模型的响应中提取文本内容"""
        if self.model_type == "ollama":
            return response_data.get("response", "")
        elif self.model_type in ["openai", "deepseek"]:
            return response_data["choices"][0]["message"]["content"]
        elif self.model_type == "volcano":
            return response_data["result"]["choices"][0]["message"]["content"]
        elif self.model_type == "qwen":
            # 根据官方格式提取响应内容
            return response_data["output"]["choices"][0]["message"]["content"]
        else:
            return json.dumps(response_data)
    
    def _save_response(self, prompt: str, response: str) -> None:
        """保存响应到文件，文件名包含模型名称和时间戳"""
        if not self.save_results or not response:
            return
            
        # 创建安全的模型名称用于文件名
        safe_model_name = "".join(c for c in self.model_name if c.isalnum() or c in (' ', '_')).rstrip()
        safe_model_name = safe_model_name.replace(' ', '_')
        
        # 生成时间戳
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 构建文件名
        filename = f"{safe_model_name}_{timestamp}.txt"
        filepath = os.path.join(self.output_dir, filename)
        
        # 写入文件
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                # 写入元数据
                f.write(f"Model: {self.model_name}\n")
                f.write(f"Type: {self.model_type}\n")
                f.write(f"Timestamp: {datetime.now().isoformat()}\n")
                f.write("\n=== Prompt ===\n")
                f.write(f"{prompt}\n")
                f.write("\n=== Response ===\n")
                f.write(f"{response}\n")
            
            logger.info(f"响应已保存到: {filepath}")
        except Exception as e:
            logger.error(f"保存响应失败: {str(e)}")
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
        before_sleep=lambda retry_state: logger.warning(
            f"Retry #{retry_state.attempt_number} for request due to"
        )
    )
    async def _make_async_request(self, session: aiohttp.ClientSession, prompt: str) -> str:
        """执行异步API请求（带重试机制）"""
        url = f"{self.base_url}{self.endpoints[self.model_type]}"
        payload = self._build_payload(prompt)
        headers = self._build_headers()
        
        async with self.semaphore:
            try:
                async with session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=self.timeout
                ) as response:
                    response.raise_for_status()
                    response_data = await response.json()
                    logger.debug(response_data)

                    # 处理API返回的错误
                    if "error" in response_data:
                        error_msg = response_data["error"].get("message", "Unknown API error")
                        logger.error(f"API error: {error_msg}")
                        raise aiohttp.ClientResponseError(
                            response.request_info,
                            response.history,
                            status=response.status,
                            message=error_msg
                        )
                    return self._extract_response(response_data)
            
            except aiohttp.ClientResponseError as e:
                logger.debug(f"Request URL: {url}")
                logger.debug(f"Request Headers: {headers}")
                logger.debug(f"Request Payload: {payload}")
                logger.error(f"HTTP error {e.status}: {e.message}")
                error_detail = await e.text()
                logger.error(f"ClientResponseError API error {e.status}: {error_detail}")
                raise
            except asyncio.TimeoutError:
                logger.debug(f"Request URL: {url}")
                logger.debug(f"Request Headers: {headers}")
                logger.debug(f"Request Payload: {payload}")
                logger.warning("Request timed out")
                raise
            except Exception as e:
                logger.debug(f"Request URL: {url}")
                logger.debug(f"Request Headers: {headers}")
                logger.debug(f"Request Payload: {payload}")
                logger.error(f"Unexpected error: {str(e)}")
                raise

    async def generate(self, session: aiohttp.ClientSession, prompt: str) -> str:
        """
        生成文本内容并保存结果
        
        :param session: aiohttp会话对象
        :param prompt: 输入的提示文本
        :return: 模型生成的文本
        """
        try:
            result = await self._make_async_request(session, prompt)
            # 生成后自动保存结果
            self._save_response(prompt, result)
            return result
        except Exception as e:
            logger.error(f"所有重试失败: {prompt[:50]}... 错误: {str(e)}")
            return ""

class AsyncBatchProcessor:
    """异步批量处理器"""
    
    def __init__(self, api_clients: List[ModelAPIClient]):
        """
        初始化批量处理器
        
        :param api_clients: 配置好的API客户端列表
        """
        self.api_clients = api_clients
        self.session = None
        logger.info(f"Initialized batch processor with {len(api_clients)} API clients")
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc, tb):
        await self.session.close()
    
    async def process_batch(self, prompts: List[str]) -> List[str]:
        """
        处理一批提示文本
        
        :param prompts: 提示文本列表
        :return: 生成结果列表
        """
        if not self.session:
            raise RuntimeError("Use async context manager (async with)")
        
        # 轮询使用不同的API客户端
        client_cycle = self._client_cycle()
        
        tasks = []
        for prompt in prompts:
            client = next(client_cycle)
            task = asyncio.create_task(client.generate(self.session, prompt))
            tasks.append(task)
            logger.debug(f"Submitted task for prompt: {prompt[:30]}...")
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 处理异常结果
        final_results = []
        for res in results:
            if isinstance(res, Exception):
                logger.error(f"Task failed: {str(res)}")
                final_results.append("")
            else:
                final_results.append(res)
        
        return final_results
    
    def _client_cycle(self):
        """无限循环提供API客户端"""
        while True:
            for client in self.api_clients:
                yield client

def get_random_question_types(task_file:str, sample_num:int):
    # 1. 加载 task.json 并随机采样 k 类任务
    with open(task_file, "r", encoding="utf-8") as f:
        task_data = json.load(f)
    while True:
        selected_categories = random.sample(list(task_data.keys()), sample_num)
        task_type_examples = []
        for category in selected_categories:
            task_list = task_data[category]
            selected_task = random.choice(task_list)
            task_type_examples.append(selected_task)
        yield task_type_examples

# 使用示例 ===============================================================================
async def main():
    # 1. 创建API客户端配置
    # openai_client = ModelAPIClient(
    #     model_type="openai",
    #     api_key="sk-your-openai-key",
    #     model_name="gpt-4-turbo",
    #     max_concurrent=5,
    #     save_results=True,  # 启用结果保存
    #     output_dir="openai_results",  # 自定义输出目录
    #     temperature=0.8,
    #     max_tokens=1000
    # )
    
    # deepseek_client = ModelAPIClient(
    #     model_type="deepseek",
    #     api_key="your-deepseek-key",
    #     model_name="deepseek-chat",
    #     max_concurrent=5,
    #     save_results=True,  # 启用结果保存
    #     output_dir="deepseek_results",
    #     top_p=0.9
    # )
    
    qwen_client = ModelAPIClient(
        model_type="qwen",
        api_key="sk-426c613869b34e508a78e0153e3198e6",
        # model_name="qwen3-235b-a22b",
        # model_name="qwen3-0.6b",
        model_name="qwen3-32b",
        max_concurrent=5,
        save_results=True,  # 启用结果保存
        output_dir="./qwen_results",
        enable_search=False,
        enable_thinking=False
    )
    
    # ollama_client = ModelAPIClient(
    #     model_type="ollama",
    #     model_name="llama3",
    #     max_concurrent=5,
    #     save_results=True,  # 启用结果保存
    #     output_dir="ollama_results",
    #     temperature=0.5,
    #     num_ctx=4096
    # )

    # 2. 准备数据
        # 配置需要读取的标题深度，比如只读取 h3
    heading_levels_to_read = [3]
    md_file_path = "./data/b19159.md"  # 替换为你的Markdown文件路径
    
    # 读取并分块处理Markdown文件
    chunks = extract_sections(
        md_file_path,
        heading_levels=heading_levels_to_read,
        chunk_max_length=4096,  # 4K字符
        min_chunk_length=256,   # 最小500字符
        debug=True,             # 调试模式
        debug_k=3               # 调试模式下只返回3个分块
    )
    
    # 打印结果
    for i, chunk in enumerate(chunks):
        print(f"\n======= Chunk {i+1} =======\n")
        print(chunk[:20])  # 打印每个分块的前1000字符
        print("\n...\n" if len(chunk) > 1000 else "")  # 如果分块过长，显示省略号
        print("=" * 50 + "\n")

    # 2. 渲染 Jinja2 模板
    with open("./prompt3.jinja2", "r", encoding="utf-8") as f:
        template_str = f.read()

    
    # 2. 初始化批量处理器
    async with AsyncBatchProcessor(
        api_clients=[qwen_client,]
    ) as processor:
        
        # 3. 准备提示文本
        prompts = [Template(template_str).render({
            "text": data,
            "n": 10,
            "task_type_examples": get_random_question_types(task_file='./task.json', sample_num=5)
        }) for data in chunks]

        # 4. 批量处理并获取结果
        results = await processor.process_batch(prompts)
        
        # 5. 输出结果
        for i, (prompt, result) in enumerate(zip(prompts, results)):
            print(f"Prompt {i+1}: {prompt[:30]}...")
            print(f"Result: {result[:100]}...\n")



if __name__ == "__main__":
    asyncio.run(main())





    # # 2. 初始化批量处理器
    # async with AsyncBatchProcessor(
    #     api_clients = [qwen_client]
    # ) as processor:
        
    #     # 3. 准备提示文本
    #     prompts = [
    #         "解释量子计算的基本原理",
    #         "写一首关于春天的诗",
    #         "如何用Python实现快速排序？",
    #         "今天的国际新闻头条是什么？",
    #         "黑洞信息悖论的当前研究进展如何？",
    #         "解释强化学习的基本概念"
    #     ]
        
    #     # 4. 批量处理并获取结果
    #     results = await processor.process_batch(prompts)
        
    #     # 5. 输出结果
    #     for i, (prompt, result) in enumerate(zip(prompts, results)):
    #         print(f"Prompt {i+1}: {prompt[:30]}...")
    #         print(f"Result: {result[:100]}...\n")



# 1. 数据加载：处理读取一个文件夹下的所有md文件（DEBUG模式给个参数，可以少些）
# 2. 持现在对每个md文件的处理，以及DEBUG模式，但是要给每个chunk一个id
# 3. 所有文件、参数统一管理

# 4. 需在API结果生成后，对结果进行整理，API生成的结果格式如下：
# 生成{{ n }}条JSON对象，每个对象包含：
# {
#   "question_type": "类型分类（如：calculate_complex_formula_calculate）",
#   "description": "对当前问题任务类型的描述",
#   "difficulty_level": "1/2/3",
#   "question": "生成的问题文本",
#   "answer": "Markdown格式的完整答案"
# }
# 对生成结果进行保存，有以下三点要求：
# 4.1. 每个chunk 送给API生成结果后，结果要总结成以下格式：
# {
#     "chunk_id": "chunk编号",
#     "chunk_text": "文段内容",
#     "instances": [
#         {
#             "question_id": "问题编号",
#             "question_type": "类型分类（如：calculate_complex_formula_calculate）",
#             "difficulty_level": "1/2/3",
#             "question": "生成的问题文本",
#             "answer": "Markdown格式的完整答案",
#         },
#         ...（一次调用生成的内容均整理在此处）
#         ]
#         }
# }
# 4.2. 结果整理dumps到文件里，文件命名为 书名_chunk_id_大模型名称_时间戳.json
# 4.3. 每次调用API会生成新的question_type description 重新dump到一个新的task.json中,与源task.json格式相同如下(question_type的前缀都是任务类型)：
#   "calculate": [
#     {
#       "question_type": "calculate_complex_formula_calculate",
#       "description": "提取完整的公式推理逻辑，并以合适的变量举例子，展示相关问题的计算过程。"
#     }
#   ],
#   "rewrite": [
#     {
#       "question_type": "rewrite_style_transfer",
#       "description": "在保持语义不变的前提下，根据指定的语言风格，重新组织润色文字内容。"
#     },
#     {
#       "question_type": "rewrite_simplification_rewrite",
#       "description": "在保持语义不变的前提下，根据字数限制或其他精简要求，重新组织文字内容。"
#     },